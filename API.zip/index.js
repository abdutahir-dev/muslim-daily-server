import app from './src/app.js';
import { initDatabases } from './src/db/connection.js';
import { appConfig } from './src/config/env.js';
import fs from 'node:fs';
import http from 'http';
import https from 'https';

const { port, host, httpsPort, certPath, keyPath, isProduction, enableHttpsInDev } = appConfig;
const startedServers = [];
const canStartHttpsInDev = enableHttpsInDev && fs.existsSync(certPath) && fs.existsSync(keyPath);
const httpsOptions = canStartHttpsInDev
    ? {
        key: fs.readFileSync(keyPath),
        cert: fs.readFileSync(certPath),
    }
    : null;

async function startServer() {
    try {
        await initDatabases();

        if (isProduction) {
            const server = app.listen(port, host, () => {
                console.log("Server running on production environment");
                console.log("HTTP Link: ", `http://${host}:${port}`);
            });
            startedServers.push(server);
        } else {
            console.log("Server running on dev environment");
            const httpServer = http.createServer(app).listen(port, host, () => {
                console.log("HTTP Link: ", `http://${host}:${port}`);
            });
            startedServers.push(httpServer);

            if (httpsOptions) {
                const httpsServer = https.createServer(httpsOptions, app).listen(httpsPort, host, () => {
                    console.log(`HTTPS Link: https://${host}:${httpsPort}`);
                });
                startedServers.push(httpsServer);
            } else {
                console.warn(`[startup] HTTPS dev server disabled. Certificate files not found at ${certPath} and ${keyPath}.`);
            }
        }
    } catch (err) {
        console.error('Failed to start server:', err);
        process.exit(1);
    }
}

startServer();

const gracefulShutdown = () => {
    console.log('Shutting down server...');
    for (const server of startedServers) {
        try {
            server.close();
        } catch (err) {
            console.error('Error while closing server:', err);
        }
    }
    process.exit(0);
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);
