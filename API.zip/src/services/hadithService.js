import { hadithDb, deenbotDb } from '../db/connection.js';
import dayjs from 'dayjs';

// returns a promise resolving to today's random hadith record
export async function getDailyHadith() {
  const today = dayjs().format('YYYY-MM-DD');

  // first check override stored in daily_content in deenbotDb
  const override = await deenbotDb.get(
    'SELECT * FROM daily_content WHERE content_type = ? AND date = ?',
    ['hadith', today]
  );
  if (override) {
    const hadith = await hadithDb.get('SELECT * FROM Hadiths WHERE id = ?', [override.content_id]);
    if (hadith) return hadith;
  }

  // no override, check hadithDb.daily_hadith table
  const existing = await hadithDb.get('SELECT * FROM daily_hadith WHERE date = ?', [today]);
  if (existing) {
    const hadith = await hadithDb.get('SELECT * FROM Hadiths WHERE id = ?', [existing.hadith_id]);
    if (hadith) return hadith;
  }

  // pick random hadith and insert
  const random = await hadithDb.get('SELECT * FROM Hadiths ORDER BY RANDOM() LIMIT 1');
  if (random) {
    await hadithDb.run('INSERT OR IGNORE INTO daily_hadith (hadith_id, date) VALUES (?, ?)', [random.id, today]);
  }
  return random;
}

// admin override
export async function overrideDailyHadith(hadithId, adminUsername) {
  const today = dayjs().format('YYYY-MM-DD');
  // insert or update override in deenbotDb.daily_content
  await deenbotDb.run(
    `INSERT INTO daily_content (content_type, content_id, date, overridden_by)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(date, content_type) DO UPDATE SET content_id=excluded.content_id, overridden_by=excluded.overridden_by`,
    ['hadith', hadithId, today, adminUsername]
  );
  // also update hadithDb.daily_hadith for completeness
  await hadithDb.run(
    `INSERT INTO daily_hadith (hadith_id, date, overridden_by)
     VALUES (?, ?, ?)
     ON CONFLICT(date) DO UPDATE SET hadith_id=excluded.hadith_id, overridden_by=excluded.overridden_by`,
    [hadithId, today, adminUsername]
  );
}

// editions, sections, listing
export async function listEditions() {
  return hadithDb.all('SELECT * FROM Edition ORDER BY name');
}

export async function listBooks() {
  return hadithDb.all('SELECT * FROM Book ORDER BY name');
}

export async function listSectionsForEdition(editionId) {
  return hadithDb.all('SELECT * FROM Section WHERE editionId = ? ORDER BY number', [editionId]);
}

export async function listHadithsForSection(sectionId, page = 1, limit = 20) {
  const offset = (page - 1) * limit;
  return hadithDb.all(
    'SELECT * FROM Hadith WHERE id BETWEEN (SELECT hadithNumberFirst FROM Section WHERE id = ?) AND (SELECT hadithNumberLast FROM Section WHERE id = ?) LIMIT ? OFFSET ?',
    [sectionId, sectionId, limit, offset]
  );
}

export async function getHadithById(id) {
  return hadithDb.get('SELECT * FROM Hadith WHERE id = ?', [id]);
}

export async function getHadithByBook(id) {
  return hadithDb.get('SELECT * FROM Hadith WHERE id = ?', [id]);
}
