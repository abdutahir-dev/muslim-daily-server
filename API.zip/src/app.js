import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { appConfig } from './config/env.js';

import authRoutes from './routes/authRoutes.js';
import quranRoutes from './routes/quranRoutes.js';
import prayerRoutes from './routes/prayerRoutes.js';
import userRoutes from './routes/userRoutes.js';
import resourceRoutes from './routes/resourceRoutes.js';
import adminRoutes from './routes/adminRoutes.js';
import analyticsRoutes from './routes/analyticsRoutes.js';
import searchRoutes from './routes/searchRoutes.js';
import socialRoutes from './routes/socialRoutes.js';
import duaRoutes from './routes/duaRoutes.js';
import hadithRoutes from './routes/hadithRoutes.js';
import audioRoutes from './routes/audioRoutes.js';
import calendarRoutes from './routes/calendarRoutes.js';
import userInfoRoutes from './routes/userInfoRoutes.js'

const app = express();

const limiter = rateLimit({
    windowMs: appConfig.rateLimitWindowMs,
    max: appConfig.rateLimitMaxRequests,
    standardHeaders: true,
    legacyHeaders: false,
    message: 'Too many requests from this IP, please try again later.',
});

const corsOptions = appConfig.allowAnyOrigin
    ? {
        origin: '*',
        methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization'],
    }
    : {
        origin: (origin, callback) => {
            if (!origin || appConfig.corsOrigins.includes(origin)) {
                callback(null, true);
                return;
            }
            callback(new Error('CORS policy blocked this origin.'));
        },
        methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization'],
    };

// Middlewares
app.set('trust proxy', appConfig.trustProxy ? 1 : 0);
app.use(cors(corsOptions));
app.use(limiter);
app.use(helmet()); // Security Headers
app.use(compression()); // Gzip compression
app.use(morgan('combined')); // HTTP request logger

app.use(express.json({ limit: appConfig.bodyLimit })); // Protect against large payloads
app.use(express.urlencoded({ extended: true, limit: appConfig.bodyLimit }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/quran', quranRoutes);
app.use('/api/prayers', prayerRoutes);
app.use('/api/user', userRoutes);
app.use('/api', resourceRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/social', socialRoutes);
app.use('/api/duas', duaRoutes);
app.use('/api/hadith', hadithRoutes);
app.use('/api/audio', audioRoutes);
app.use('/api/calendar', calendarRoutes);
app.use('/api/user-info', userInfoRoutes);

// Legacy/Compatibility routes
app.use('/api', quranRoutes);

const healthHandler = (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
};
app.get('/health', healthHandler);
app.get('/api/health', healthHandler);

// Global Error Handler
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        error: 'Internal Server Error',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong on the server.'
    });
});



export default app;
